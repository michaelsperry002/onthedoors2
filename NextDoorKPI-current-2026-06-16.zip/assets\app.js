const ACTIVITY_KEY = "nextdoorkpi.activities.v2";
const USER_KEY = "nextdoorkpi.users.v1";
const SESSION_KEY = "nextdoorkpi.session.v1";
const GO_BACK_KEY = "nextdoorkpi.gobacks.v1";
const TIMEZONE_KEY = "nextdoorkpi.timezone.v1";

const outcomeMeta = {
  "no-answer": { label: "No answer", badge: "" },
  "not-interested": { label: "Not interested", badge: "red" },
  "go-back": { label: "Go back", badge: "blue" },
  yelled: { label: "Grumpy grandpa", badge: "red" },
  contacted: { label: "Answered", badge: "yellow" },
  sale: { label: "Sale closed", badge: "green" },
};

const roleMeta = {
  admin: "Admin",
  manager: "Manager",
  rep: "Rep",
};

const defaultGoals = {
  doors: 80,
  contacts: 30,
  appointments: 5,
  sales: 2,
};

const defaultBaselines = {
  contactRate: 35,
  appointmentRate: 15,
  closeRate: 8,
};

const minimumSamples = {
  contactRate: 20,
  appointmentRate: 10,
  closeRate: 10,
};

let users = readJson(USER_KEY, []);
let activities = readJson(ACTIVITY_KEY, []);
let session = readJson(SESSION_KEY, null);
let goBackAlarms = readJson(GO_BACK_KEY, []);
let selectedTimeZone = localStorage.getItem(TIMEZONE_KEY) || "America/Denver";
let currentUser = null;
let viewedUserId = "all";
let activeRange = "today";
let activeTab = "dashboard";

const els = {
  loginScreen: document.querySelector("#loginScreen"),
  loginForm: document.querySelector("#loginForm"),
  loginEmail: document.querySelector("#loginEmail"),
  loginPassword: document.querySelector("#loginPassword"),
  googleLoginBtn: document.querySelector("#googleLoginBtn"),
  loginError: document.querySelector("#loginError"),
  topClock: document.querySelector("#topClock"),
  timeZoneSelect: document.querySelector("#timeZoneSelect"),
  alarmBanner: document.querySelector("#alarmBanner"),
  todayLabel: document.querySelector("#todayLabel"),
  kpiGrid: document.querySelector("#kpiGrid"),
  progressList: document.querySelector("#progressList"),
  revenueChart: document.querySelector("#revenueChart"),
  outcomeChart: document.querySelector("#outcomeChart"),
  paceChart: document.querySelector("#paceChart"),
  insightList: document.querySelector("#insightList"),
  rangeLabel: document.querySelector("#rangeLabel"),
  followUpList: document.querySelector("#followUpList"),
  followUpCount: document.querySelector("#followUpCount"),
  activityForm: document.querySelector("#activityForm"),
  editingActivityId: document.querySelector("#editingActivityId"),
  selectedOutcome: document.querySelector("#selectedOutcome"),
  saleFields: document.querySelector("#saleFields"),
  contractValue: document.querySelector("#contractValue"),
  saveQuickLogBtn: document.querySelector("#saveQuickLogBtn"),
  cancelEditBtn: document.querySelector("#cancelEditBtn"),
  goBackForm: document.querySelector("#goBackForm"),
  goBackName: document.querySelector("#goBackName"),
  goBackAddress: document.querySelector("#goBackAddress"),
  goBackHours: document.querySelector("#goBackHours"),
  goBackMinutes: document.querySelector("#goBackMinutes"),
  goBackSeconds: document.querySelector("#goBackSeconds"),
  goBackProjected: document.querySelector("#goBackProjected"),
  goBackNotes: document.querySelector("#goBackNotes"),
  goBackList: document.querySelector("#goBackList"),
  historyList: document.querySelector("#historyList"),
  searchInput: document.querySelector("#searchInput"),
  logoutBtn: document.querySelector("#logoutBtn"),
  viewUser: document.querySelector("#viewUser"),
  currentUserName: document.querySelector("#currentUserName"),
  currentUserRole: document.querySelector("#currentUserRole"),
  goalDoors: document.querySelector("#goalDoors"),
  goalContacts: document.querySelector("#goalContacts"),
  goalAppointments: document.querySelector("#goalAppointments"),
  goalSales: document.querySelector("#goalSales"),
  userForm: document.querySelector("#userForm"),
  userList: document.querySelector("#userList"),
  newUserName: document.querySelector("#newUserName"),
  newUserEmail: document.querySelector("#newUserEmail"),
  newUserRole: document.querySelector("#newUserRole"),
  newUserPassword: document.querySelector("#newUserPassword"),
  newUserConfirmPassword: document.querySelector("#newUserConfirmPassword"),
  settingsOwnerLabel: document.querySelector("#settingsOwnerLabel"),
  settingsForm: document.querySelector("#settingsForm"),
  settingsGoalDoors: document.querySelector("#settingsGoalDoors"),
  settingsGoalContacts: document.querySelector("#settingsGoalContacts"),
  settingsGoalAppointments: document.querySelector("#settingsGoalAppointments"),
  settingsGoalSales: document.querySelector("#settingsGoalSales"),
  baselineForm: document.querySelector("#baselineForm"),
  baselineContactRate: document.querySelector("#baselineContactRate"),
  baselineAppointmentRate: document.querySelector("#baselineAppointmentRate"),
  baselineCloseRate: document.querySelector("#baselineCloseRate"),
  customKpiForm: document.querySelector("#customKpiForm"),
  customKpiName: document.querySelector("#customKpiName"),
  customKpiCurrent: document.querySelector("#customKpiCurrent"),
  customKpiTarget: document.querySelector("#customKpiTarget"),
  customKpiList: document.querySelector("#customKpiList"),
  plannerDaySales: document.querySelector("#plannerDaySales"),
  plannerWeekSales: document.querySelector("#plannerWeekSales"),
  plannerMonthSales: document.querySelector("#plannerMonthSales"),
  plannerSummerSales: document.querySelector("#plannerSummerSales"),
  plannerSummerWeeks: document.querySelector("#plannerSummerWeeks"),
  goalPlannerResults: document.querySelector("#goalPlannerResults"),
};

init();

function init() {
  ensureDefaultUsers();
  normalizeUsers();
  migrateOldActivities();
  bindEvents();
  els.timeZoneSelect.value = selectedTimeZone;
  restoreSession();
  activateTab(location.hash.replace("#", "") || "dashboard");
  updateClock();
  updateProjectedGoBackTime();
  setInterval(updateClock, 1000);
  setInterval(checkGoBackAlarms, 1000);
  setInterval(() => {
    if (currentUser && activeTab === "gobacks") renderGoBackAlarms();
  }, 30000);

  els.todayLabel.textContent = new Intl.DateTimeFormat(undefined, {
    weekday: "long",
    month: "long",
    day: "numeric",
  }).format(new Date());
}

function bindEvents() {
  els.loginForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const email = els.loginEmail.value.trim().toLowerCase();
    const password = els.loginPassword.value;
    const user = users.find((item) => item.email.toLowerCase() === email);

    if (!user || user.password !== password) {
      els.loginError.textContent = "That email or password does not match.";
      return;
    }

    session = { userId: user.id };
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    els.loginPassword.value = "";
    els.loginError.textContent = "";
    signIn(user);
  });

  els.googleLoginBtn.addEventListener("click", () => {
    els.loginError.textContent = "Google sign-in needs Supabase, Firebase, or another hosted auth service.";
  });

  els.logoutBtn.addEventListener("click", () => {
    session = null;
    currentUser = null;
    localStorage.removeItem(SESSION_KEY);
    document.body.classList.add("logged-out");
  });

  document.querySelectorAll("[data-tab-link]").forEach((link) => {
    link.addEventListener("click", (event) => {
      event.preventDefault();
      activateTab(link.dataset.tabLink);
    });
  });

  window.addEventListener("hashchange", () => {
    activateTab(location.hash.replace("#", "") || "dashboard");
  });

  els.timeZoneSelect.addEventListener("change", () => {
    selectedTimeZone = els.timeZoneSelect.value;
    localStorage.setItem(TIMEZONE_KEY, selectedTimeZone);
    updateClock();
    updateProjectedGoBackTime();
    renderGoBackAlarms();
  });

  [els.goBackHours, els.goBackMinutes, els.goBackSeconds].forEach((input) => {
    input.addEventListener("input", updateProjectedGoBackTime);
  });

  els.goBackForm.addEventListener("submit", (event) => {
    event.preventDefault();
    createGoBackAlarm();
  });

  document.querySelectorAll(".tab-button").forEach((button) => {
    button.addEventListener("click", () => {
      activeRange = button.dataset.range;
      document.querySelectorAll(".tab-button").forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      renderDashboard();
    });
  });

  els.viewUser.addEventListener("change", () => {
    viewedUserId = els.viewUser.value;
    render();
  });

  document.querySelectorAll("[data-quick-outcome]").forEach((button) => {
    button.addEventListener("click", () => handleQuickOutcome(button.dataset.quickOutcome));
  });

  document.querySelectorAll("[data-quick-outcome]").forEach((button) => {
    const counter = document.createElement("span");
    counter.className = "quick-count";
    counter.textContent = "0";
    button.append(counter);

    const decrement = document.createElement("span");
    decrement.className = "quick-decrement";
    decrement.textContent = "↓";
    decrement.setAttribute("role", "button");
    decrement.setAttribute("tabindex", "0");
    decrement.setAttribute("aria-label", `Lower ${button.textContent.trim()} by one`);
    button.append(decrement);

    const undo = (event) => {
      event.preventDefault();
      event.stopPropagation();
      decrementQuickOutcome(button.dataset.quickOutcome);
    };
    decrement.addEventListener("click", undo);
    decrement.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") undo(event);
    });
  });

  els.activityForm.addEventListener("submit", (event) => {
    event.preventDefault();
    saveSelectedQuickLog();
  });

  els.cancelEditBtn.addEventListener("click", resetQuickLogForm);

  [els.goalDoors, els.goalContacts, els.goalAppointments, els.goalSales].forEach((input) => {
    input.addEventListener("input", () => {
      const targetUser = getSettingsUser();
      targetUser.goals = {
        doors: Number(els.goalDoors.value) || defaultGoals.doors,
        contacts: Number(els.goalContacts.value) || defaultGoals.contacts,
        appointments: Number(els.goalAppointments.value) || defaultGoals.appointments,
        sales: Number(els.goalSales.value) || defaultGoals.sales,
      };
      saveUsers();
      syncSettingsInputs();
      renderDashboard();
    });
  });

  els.settingsForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const targetUser = getSettingsUser();
    targetUser.goals = {
      doors: Number(els.settingsGoalDoors.value) || defaultGoals.doors,
      contacts: Number(els.settingsGoalContacts.value) || defaultGoals.contacts,
      appointments: Number(els.settingsGoalAppointments.value) || defaultGoals.appointments,
      sales: Number(els.settingsGoalSales.value) || defaultGoals.sales,
    };
    saveUsers();
    syncGoalInputs();
    renderDashboard();
    renderGoalPlanner();
  });

  els.baselineForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const targetUser = getSettingsUser();
    targetUser.baselines = {
      contactRate: clampPercent(els.baselineContactRate.value),
      appointmentRate: clampPercent(els.baselineAppointmentRate.value),
      closeRate: clampPercent(els.baselineCloseRate.value),
    };
    saveUsers();
    renderDashboard();
    renderGoalPlanner();
  });

  els.customKpiForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const name = els.customKpiName.value.trim();
    if (!name) return;

    const targetUser = getSettingsUser();
    targetUser.customKpis = [
      ...(targetUser.customKpis || []),
      {
        id: createId(),
        name,
        current: clampPercent(els.customKpiCurrent.value),
        target: clampPercent(els.customKpiTarget.value),
      },
    ];

    els.customKpiForm.reset();
    saveUsers();
    renderCustomKpis();
  });

  [
    els.plannerDaySales,
    els.plannerWeekSales,
    els.plannerMonthSales,
    els.plannerSummerSales,
    els.plannerSummerWeeks,
  ].forEach((input) => {
    input.addEventListener("input", renderGoalPlanner);
  });

  els.userForm.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!canManageUsers()) return;

    const role = els.newUserRole.value;
    if (currentUser.role === "manager" && role !== "rep") {
      alert("Managers can add reps. Admins can add managers and admins.");
      return;
    }

    const name = els.newUserName.value.trim();
    const password = els.newUserPassword.value;
    const confirmPassword = els.newUserConfirmPassword.value;
    if (!name || password.length < 8) {
      alert("Add a name and a password with at least 8 characters.");
      return;
    }
    if (password !== confirmPassword) {
      alert("Passwords do not match.");
      return;
    }

    users = [
      ...users,
      {
        id: createId(),
        name,
        email: els.newUserEmail.value.trim(),
        role,
        password,
        goals: { ...defaultGoals },
        baselines: { ...defaultBaselines },
        customKpis: [],
      },
    ];

    els.userForm.reset();
    saveUsers();
    renderUserControls();
    renderUsers();
  });

  els.searchInput.addEventListener("input", renderHistory);
}

function restoreSession() {
  const user = users.find((item) => item.id === session?.userId);
  if (user) {
    signIn(user);
    return;
  }

  document.body.classList.add("logged-out");
}

function signIn(user) {
  currentUser = user;
  viewedUserId = canViewTeam() ? "all" : user.id;
  document.body.classList.remove("logged-out");
  renderUserControls();
  render();
}

function activateTab(tabId) {
  const target = document.querySelector(`#${tabId}`);
  const isAdminBlocked = target?.classList.contains("admin-only") && !canManageUsers();
  activeTab = target && !isAdminBlocked ? tabId : "dashboard";

  document.querySelectorAll(".tab-view").forEach((view) => {
    view.classList.toggle("active-view", view.id === activeTab);
  });

  document.querySelectorAll("[data-tab-link]").forEach((link) => {
    link.classList.toggle("active", link.dataset.tabLink === activeTab);
  });

  if (location.hash !== `#${activeTab}`) {
    history.replaceState(null, "", `#${activeTab}`);
  }

  window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  document.querySelector(".workspace")?.scrollTo?.({ top: 0, left: 0, behavior: "auto" });
}

function handleQuickOutcome(outcome) {
  setSelectedOutcome(outcome);
  playQuickLogFeedback(outcome);

  if (outcome === "sale") {
    els.saleFields.classList.remove("hidden");
    els.saveQuickLogBtn.classList.remove("hidden");
    els.contractValue.focus();
    return;
  }

  if (els.editingActivityId.value) {
    els.saveQuickLogBtn.classList.remove("hidden");
    return;
  }

  createQuickActivity({
    outcome,
    followUpDate: valueOf("#followUpDate"),
    notes: valueOf("#notes"),
  });
}

function saveSelectedQuickLog() {
  const outcome = els.selectedOutcome.value;
  if (!outcome) return;

  const id = els.editingActivityId.value;
  const payload = {
    outcome,
    revenue: outcome === "sale" ? Number(els.contractValue.value) || 0 : 0,
    followUpDate: valueOf("#followUpDate"),
    notes: valueOf("#notes"),
  };

  if (id) {
    activities = activities.map((activity) =>
      activity.id === id
        ? {
            ...activity,
            ...payload,
            address: quickLogTitle(payload.outcome),
          }
        : activity,
    );
  } else {
    createQuickActivity(payload);
    return;
  }

  saveActivities();
  resetQuickLogForm();
  render();
}

function createQuickActivity(payload) {
  const outcome = payload.outcome;
  const activity = {
    id: createId(),
    ownerId: currentUser.id,
    createdAt: new Date().toISOString(),
    address: quickLogTitle(outcome),
    contactName: "",
    outcome,
    revenue: payload.revenue || 0,
    followUpDate: payload.followUpDate || "",
    notes: payload.notes || "",
  };

  activities = [activity, ...activities];
  saveActivities();
  resetQuickLogForm();
  render();
}

function decrementQuickOutcome(outcome) {
  const match = activities.find(
    (activity) =>
      activity.ownerId === currentUser.id &&
      activity.outcome === outcome &&
      inRange(activity.createdAt, "today"),
  );

  if (!match) return;
  activities = activities.filter((activity) => activity.id !== match.id);
  saveActivities();
  render();
}

function editActivity(id) {
  const activity = activities.find((item) => item.id === id);
  if (!activity || !canDeleteActivity(activity)) return;

  els.editingActivityId.value = activity.id;
  els.followUpDate.value = activity.followUpDate || "";
  els.notes.value = activity.notes || "";
  els.contractValue.value = activity.revenue || "";
  setSelectedOutcome(activity.outcome);
  els.saveQuickLogBtn.textContent = "Update quick log";
  els.saveQuickLogBtn.classList.remove("hidden");
  els.cancelEditBtn.classList.remove("hidden");
  document.querySelector("#log").scrollIntoView({ behavior: "smooth", block: "start" });
}

function setSelectedOutcome(outcome) {
  els.selectedOutcome.value = outcome;
  document.querySelectorAll("[data-quick-outcome]").forEach((button) => {
    button.classList.toggle("selected", button.dataset.quickOutcome === outcome);
  });
  els.saleFields.classList.toggle("hidden", outcome !== "sale");
}

function resetQuickLogForm() {
  els.activityForm.reset();
  els.editingActivityId.value = "";
  els.selectedOutcome.value = "";
  els.saveQuickLogBtn.textContent = "Save quick log";
  els.saveQuickLogBtn.classList.add("hidden");
  els.cancelEditBtn.classList.add("hidden");
  els.saleFields.classList.add("hidden");
  document.querySelectorAll("[data-quick-outcome]").forEach((button) => {
    button.classList.remove("selected");
  });
}

function playQuickLogFeedback(outcome) {
  const button = document.querySelector(`[data-quick-outcome="${outcome}"]`);
  if (!button) return;
  button.classList.remove("logged-pulse");
  void button.offsetWidth;
  button.classList.add("logged-pulse");
  setTimeout(() => button.classList.remove("logged-pulse"), 1400);
}

function createGoBackAlarm() {
  const name = els.goBackName.value.trim();
  const address = els.goBackAddress.value.trim();
  const delayMs = getGoBackDelayMs();

  if (!name || !address) {
    alert("Add a name and address for the go back.");
    return;
  }

  if (!delayMs) {
    alert("Add at least a few seconds for the wait time.");
    return;
  }

  const dueAt = Date.now() + delayMs;
  goBackAlarms = [
    {
      id: createId(),
      ownerId: currentUser.id,
      name,
      address,
      notes: els.goBackNotes.value.trim(),
      delayMs,
      createdAt: new Date().toISOString(),
      dueAt,
      status: "open",
    },
    ...goBackAlarms,
  ];

  saveGoBackAlarms();
  els.goBackForm.reset();
  els.goBackHours.value = "1";
  els.goBackMinutes.value = "0";
  els.goBackSeconds.value = "0";
  updateProjectedGoBackTime();
  renderGoBackAlarms();
}

function renderGoBackAlarms() {
  const visible = scopedGoBackAlarms().sort((a, b) => a.dueAt - b.dueAt);
  els.goBackList.innerHTML = visible.length
    ? visible.map(goBackCard).join("")
    : emptyState("No go-back alarms set", "Add a person, address, and wait time to start a return timer.");

  els.goBackList.querySelectorAll("[data-goback-done]").forEach((button) => {
    button.addEventListener("click", () => {
      updateGoBackStatus(button.dataset.gobackDone, "done");
    });
  });

  els.goBackList.querySelectorAll("[data-goback-delete]").forEach((button) => {
    button.addEventListener("click", () => {
      goBackAlarms = goBackAlarms.filter((alarm) => alarm.id !== button.dataset.gobackDelete);
      saveGoBackAlarms();
      renderGoBackAlarms();
      checkGoBackAlarms();
    });
  });
}

function goBackCard(alarm) {
  const now = Date.now();
  const due = alarm.dueAt <= now && alarm.status === "open";
  return `
    <article class="record-card goback-card ${due ? "due" : ""}">
      <div class="record-top">
        <div>
          <h4 class="record-title">${escapeHtml(alarm.name)}</h4>
          <p class="record-subtitle">${escapeHtml(alarm.address)}</p>
          ${alarm.notes ? `<p class="record-notes">${escapeHtml(alarm.notes)}</p>` : ""}
        </div>
        <div class="record-actions">
          <button class="delete-button" type="button" data-goback-done="${alarm.id}">Done</button>
          <button class="delete-button" type="button" data-goback-delete="${alarm.id}">Delete</button>
        </div>
      </div>
      <div class="badge-row">
        <span class="badge ${due ? "green" : "blue"}">${due ? "Due now" : timeUntil(alarm.dueAt)}</span>
        <span class="badge">Alarm ${formatTime(alarm.dueAt)}</span>
        <span class="badge">${escapeHtml(userName(alarm.ownerId))}</span>
      </div>
    </article>
  `;
}

function checkGoBackAlarms() {
  const due = scopedGoBackAlarms().filter((alarm) => alarm.status === "open" && alarm.dueAt <= Date.now());
  if (!due.length) {
    els.alarmBanner.classList.add("hidden");
    return;
  }

  const first = due[0];
  els.alarmBanner.classList.remove("hidden");
  els.alarmBanner.innerHTML = `
    <strong>Go back now:</strong>
    <span>${escapeHtml(first.name)} at ${escapeHtml(first.address)}</span>
    <button class="secondary-button" type="button" data-dismiss-alarm>Mark done</button>
  `;
  els.alarmBanner.querySelector("[data-dismiss-alarm]").addEventListener("click", () => {
    updateGoBackStatus(first.id, "done");
  });
}

function updateGoBackStatus(id, status) {
  goBackAlarms = goBackAlarms.map((alarm) => (alarm.id === id ? { ...alarm, status } : alarm));
  saveGoBackAlarms();
  renderGoBackAlarms();
  checkGoBackAlarms();
}

function scopedGoBackAlarms() {
  if (canViewTeam() && viewedUserId === "all") return goBackAlarms.filter((alarm) => alarm.status === "open");
  return goBackAlarms.filter((alarm) => alarm.ownerId === viewedUserId && alarm.status === "open");
}

function updateProjectedGoBackTime() {
  const delayMs = getGoBackDelayMs();
  els.goBackProjected.textContent = formatTime(Date.now() + delayMs);
}

function updateClock() {
  els.topClock.textContent = formatTime(Date.now(), { includeSeconds: true });
}

function render() {
  if (!currentUser) return;
  applyPermissions();
  syncGoalInputs();
  syncSettingsInputs();
  renderDashboard();
  renderGoBackAlarms();
  renderHistory();
  renderUsers();
  renderCustomKpis();
  renderGoalPlanner();
  renderQuickCounts();
}

function applyPermissions() {
  document.querySelectorAll(".admin-only").forEach((item) => {
    item.classList.toggle("hidden", !canManageUsers());
  });

  if (document.querySelector(`#${activeTab}`)?.classList.contains("hidden")) {
    activateTab("dashboard");
  }

  els.currentUserName.textContent = currentUser.name;
  els.currentUserRole.textContent = roleMeta[currentUser.role];
}

function renderUserControls() {
  const options = canViewTeam()
    ? [
        `<option value="all">All users</option>`,
        ...users.map((user) => `<option value="${user.id}">${escapeHtml(user.name)}</option>`),
      ]
    : [`<option value="${currentUser.id}">${escapeHtml(currentUser.name)}</option>`];

  els.viewUser.innerHTML = options.join("");
  els.viewUser.value = viewedUserId;
}

function renderDashboard() {
  const rangeActivities = scopedActivities().filter((activity) => inRange(activity.createdAt, activeRange));
  const stats = getStats(rangeActivities);
  const rates = getModeledRates(stats);
  const projectedSales = Math.round((stats.contacts * rates.closeRate) / 100);

  const cards = [
    ["Doors", stats.doors, `${percent(stats.doors, rangeGoal("doors"))}% of goal`],
    ["Doors Answered", stats.contacts, `${rates.contactRate}% answer rate ${rateSource(rates.contactRateSource)}`],
    ["Go backs", stats.appointments, `${rates.appointmentRate}% go-back rate ${rateSource(rates.appointmentRateSource)}`],
    ["Sales", stats.sales, `$${formatMoney(stats.revenue)} contract value`],
    ["Close Rate", `${rates.closeRate}%`, `${rateSource(rates.closeRateSource)} from ${stats.contacts} answered`],
    ["Projected Sales", projectedSales, "Uses answered doors and close rate"],
  ];

  els.kpiGrid.innerHTML = cards
    .map(
      ([label, value, sub]) => `
        <article class="kpi-card">
          <div class="kpi-label">${label}</div>
          <div class="kpi-value">${value}</div>
          <div class="kpi-sub">${sub}</div>
        </article>
      `,
    )
    .join("");

  els.rangeLabel.textContent = labelForRange(activeRange);
  renderProgress(stats);
  renderFollowUps();
  renderDashboardCharts();
}

function renderProgress(stats) {
  const rows = [
    ["Doors knocked", stats.doors, rangeGoal("doors")],
    ["Doors answered", stats.contacts, rangeGoal("contacts")],
    ["Go backs", stats.appointments, rangeGoal("appointments")],
    ["Sales closed", stats.sales, rangeGoal("sales")],
  ];

  els.progressList.innerHTML = rows
    .map(([label, value, goal]) => {
      const width = Math.min(percent(value, goal), 100);
      return `
        <div class="progress-row">
          <div class="progress-meta">
            <span>${label}</span>
            <span>${value} / ${goal}</span>
          </div>
          <div class="progress-track">
            <div class="progress-fill" style="width: ${width}%"></div>
          </div>
        </div>
      `;
    })
    .join("");
}

function renderFollowUps() {
  const upcoming = scopedActivities({ includeRange: false })
    .filter((activity) => activity.followUpDate && activity.outcome !== "sale")
    .sort((a, b) => a.followUpDate.localeCompare(b.followUpDate))
    .slice(0, 6);

  els.followUpCount.textContent = `${upcoming.length} open`;
  els.followUpList.innerHTML = upcoming.length
    ? upcoming.map((activity) => recordCard(activity, { compact: true })).join("")
    : emptyState("No follow-ups scheduled", "Add a follow-up date while logging a knock.");
}

function renderDashboardCharts() {
  const visible = scopedActivities({ includeRange: false });
  const revenueRows = [
    ["Today", revenueForRange(visible, "today")],
    ["Week", revenueForRange(visible, "week")],
    ["Month", revenueForRange(visible, "month")],
    ["Year", revenueForRange(visible, "year")],
  ];
  renderBarChart(els.revenueChart, revenueRows, { money: true });

  const outcomeRows = Object.entries(outcomeMeta).map(([outcome, meta]) => [
    meta.label,
    visible.filter((activity) => activity.outcome === outcome).length,
  ]);
  renderBarChart(els.outcomeChart, outcomeRows);
  renderSalesPace(visible);
  renderInsights(visible);
}

function renderBarChart(target, rows, options = {}) {
  const max = Math.max(...rows.map(([, value]) => value), 1);
  target.innerHTML = rows
    .map(([label, value]) => {
      const width = Math.max(4, Math.round((value / max) * 100));
      const display = options.money ? `$${formatMoney(value)}` : value;
      return `
        <div class="chart-row">
          <div class="chart-meta">
            <span>${escapeHtml(label)}</span>
            <strong>${display}</strong>
          </div>
          <div class="chart-track">
            <div class="chart-fill" style="width: ${width}%"></div>
          </div>
        </div>
      `;
    })
    .join("");
}

function renderSalesPace(list) {
  const rows = [];
  for (let offset = 6; offset >= 0; offset -= 1) {
    const date = new Date();
    date.setDate(date.getDate() - offset);
    const label = new Intl.DateTimeFormat(undefined, { weekday: "short" }).format(date);
    const sales = list.filter(
      (activity) =>
        activity.outcome === "sale" &&
        startOfDay(new Date(activity.createdAt)).getTime() === startOfDay(date).getTime(),
    ).length;
    rows.push([label, sales]);
  }

  const max = Math.max(...rows.map(([, value]) => value), 1);
  els.paceChart.innerHTML = rows
    .map(
      ([label, value]) => `
        <div class="mini-bar">
          <div class="mini-fill" style="height: ${Math.max(8, Math.round((value / max) * 100))}%"></div>
          <strong>${value}</strong>
          <span>${label}</span>
        </div>
      `,
    )
    .join("");
}

function renderInsights(list) {
  const stats = getStats(list);
  const rates = getModeledRates(stats);
  const doorsPerSale = doorsNeededForSales(1, rates);
  const monthRevenue = revenueForRange(list, "month");
  const avgContract = stats.sales ? Math.round(stats.revenue / stats.sales) : 0;
  const insights = [
    `Estimated doors per sale: ${doorsPerSale || "not enough data"}.`,
    `Month-to-date contract value: $${formatMoney(monthRevenue)}.`,
    `Average contract value: $${formatMoney(avgContract)}.`,
    `Every 100 doors projects about ${Math.round((100 * rates.contactRate * rates.closeRate) / 10000)} sales.`,
  ];

  els.insightList.innerHTML = insights.map((item) => `<div class="insight-item">${item}</div>`).join("");
}

function renderHistory() {
  const search = els.searchInput.value.trim().toLowerCase();
  const filtered = scopedActivities({ includeRange: false }).filter((activity) => {
    const haystack = [
      activity.address,
      activity.contactName,
      activity.notes,
      outcomeMeta[activity.outcome]?.label,
      userName(activity.ownerId),
    ]
      .join(" ")
      .toLowerCase();
    return haystack.includes(search);
  });

  els.historyList.innerHTML = filtered.length
    ? filtered
        .map((activity) =>
          recordCard(activity, {
            showDelete: canDeleteActivity(activity),
            showEdit: canDeleteActivity(activity),
          }),
        )
        .join("")
    : emptyState("No activity found", "Try a different search or log a new door knock.");

  els.historyList.querySelectorAll("[data-edit]").forEach((button) => {
    button.addEventListener("click", () => editActivity(button.dataset.edit));
  });

  els.historyList.querySelectorAll("[data-delete]").forEach((button) => {
    button.addEventListener("click", () => {
      activities = activities.filter((activity) => activity.id !== button.dataset.delete);
      saveActivities();
      render();
    });
  });
}

function renderUsers() {
  if (!canManageUsers()) {
    els.userList.innerHTML = "";
    return;
  }

  els.userList.innerHTML = users
    .map((user) => {
      const canDelete =
        user.id !== currentUser.id && (currentUser.role === "admin" || user.role === "rep");
      return `
        <article class="record-card user-card">
          <div>
            <h4 class="record-title">${escapeHtml(user.name)}</h4>
            <p class="record-subtitle">${escapeHtml(user.email || "No email")} | ${roleMeta[user.role]}</p>
          </div>
          <div class="badge-row">
            <span class="badge">${user.goals.doors} doors/day</span>
            <span class="badge">${user.baselines.closeRate}% starting close rate</span>
            ${
              canDelete
                ? `<button class="delete-button danger-outline" type="button" data-user-delete="${user.id}">Remove user</button>`
                : ""
            }
          </div>
        </article>
      `;
    })
    .join("");

  els.userList.querySelectorAll("[data-user-delete]").forEach((button) => {
    button.addEventListener("click", () => {
      const id = button.dataset.userDelete;
      const user = users.find((item) => item.id === id);
      if (!user) return;
      const typed = prompt(`Type REMOVE ${user.name} to delete this user and their saved activity.`);
      if (typed !== `REMOVE ${user.name}`) return;
      users = users.filter((user) => user.id !== id);
      activities = activities.filter((activity) => activity.ownerId !== id);
      goBackAlarms = goBackAlarms.filter((alarm) => alarm.ownerId !== id);
      if (viewedUserId === id) viewedUserId = "all";
      saveUsers();
      saveActivities();
      saveGoBackAlarms();
      renderUserControls();
      render();
    });
  });
}

function renderCustomKpis() {
  const targetUser = getSettingsUser();
  const kpis = targetUser.customKpis || [];

  els.customKpiList.innerHTML = kpis.length
    ? kpis
        .map(
          (kpi) => `
            <article class="record-card">
              <div class="record-top">
                <div>
                  <h4 class="record-title">${escapeHtml(kpi.name)}</h4>
                  <p class="record-subtitle">${kpi.current}% current / ${kpi.target}% target</p>
                </div>
                <button class="delete-button" type="button" data-kpi-delete="${kpi.id}">Delete</button>
              </div>
              <div class="progress-track">
                <div class="progress-fill" style="width: ${Math.min(percent(kpi.current, kpi.target), 100)}%"></div>
              </div>
            </article>
          `,
        )
        .join("")
    : emptyState("No custom percentages yet", "Add a personal metric like demo-to-close or pitch-to-install.");

  els.customKpiList.querySelectorAll("[data-kpi-delete]").forEach((button) => {
    button.addEventListener("click", () => {
      targetUser.customKpis = targetUser.customKpis.filter((kpi) => kpi.id !== button.dataset.kpiDelete);
      saveUsers();
      renderCustomKpis();
    });
  });
}

function renderGoalPlanner() {
  const rates = combinedModeledRates();
  const goals = [
    ["Day", Number(els.plannerDaySales.value) || 0, 1],
    ["Week", Number(els.plannerWeekSales.value) || 0, 7],
    ["Month", Number(els.plannerMonthSales.value) || 0, 30],
    ["Summer", Number(els.plannerSummerSales.value) || 0, Math.max(Number(els.plannerSummerWeeks.value) || 1, 1) * 7],
  ];

  els.goalPlannerResults.innerHTML = goals
    .map(([label, salesGoal, days]) => {
      const doors = doorsNeededForSales(salesGoal, rates);
      const answered = Math.ceil(doors * ((rates.contactRate || 0) / 100));
      const dailyDoors = days ? Math.ceil(doors / days) : doors;
      return `
        <article class="planner-card">
          <h4>${label}</h4>
          <strong>${doors}</strong>
          <span>doors needed</span>
          <div class="planner-detail">${dailyDoors}/day pace | ${answered} answered doors</div>
        </article>
      `;
    })
    .join("");
}

function renderQuickCounts() {
  const todayActivities = activities.filter(
    (activity) => activity.ownerId === currentUser.id && inRange(activity.createdAt, "today"),
  );

  document.querySelectorAll("[data-quick-outcome]").forEach((button) => {
    const outcome = button.dataset.quickOutcome;
    const count = todayActivities.filter((activity) => activity.outcome === outcome).length;
    button.querySelector(".quick-count").textContent = count;
    button.querySelector(".quick-decrement").classList.toggle("disabled", count === 0);
  });
}

function recordCard(activity, options = {}) {
  const meta = outcomeMeta[activity.outcome] || outcomeMeta["no-answer"];
  const followUp = activity.followUpDate
    ? `<span class="badge blue">Follow-up ${formatDate(activity.followUpDate)}</span>`
    : "";
  const revenue = activity.revenue ? `<span class="badge green">$${formatMoney(activity.revenue)}</span>` : "";
  const owner = canViewTeam() ? `<span class="badge">${escapeHtml(userName(activity.ownerId))}</span>` : "";
  const name = activity.contactName ? `${escapeHtml(activity.contactName)} - ` : "";
  const editButton = options.showEdit
    ? `<button class="delete-button" type="button" data-edit="${activity.id}">Edit</button>`
    : "";
  const deleteButton = options.showDelete
    ? `<button class="delete-button" type="button" data-delete="${activity.id}">Delete</button>`
    : "";

  return `
    <article class="record-card">
      <div class="record-top">
        <div>
          <h4 class="record-title">${escapeHtml(activity.address || quickLogTitle(activity.outcome))}</h4>
          <p class="record-subtitle">${name}${formatDateTime(activity.createdAt)}</p>
        </div>
        <div class="record-actions">${editButton}${deleteButton}</div>
      </div>
      <div class="badge-row">
        <span class="badge ${meta.badge}">${meta.label}</span>
        ${owner}
        ${followUp}
        ${revenue}
      </div>
      ${
        options.compact || !activity.notes
          ? ""
          : `<p class="record-notes">${escapeHtml(activity.notes)}</p>`
      }
    </article>
  `;
}

function getStats(list) {
  const doors = list.length;
  const contacts = list.filter((activity) => activity.outcome !== "no-answer").length;
  const appointments = list.filter((activity) => activity.outcome === "go-back").length;
  const sales = list.filter((activity) => activity.outcome === "sale").length;
  const revenue = list.reduce((total, activity) => total + (Number(activity.revenue) || 0), 0);

  return {
    doors,
    contacts,
    appointments,
    sales,
    revenue,
    contactRate: percent(contacts, doors),
    appointmentRate: percent(appointments, contacts),
    closeRate: percent(sales, contacts),
  };
}

function getModeledRates(stats) {
  const baseline = combinedBaselines();
  return {
    contactRate:
      stats.doors >= minimumSamples.contactRate ? stats.contactRate : baseline.contactRate,
    contactRateSource: stats.doors >= minimumSamples.contactRate ? "calculated" : "starting",
    appointmentRate:
      stats.contacts >= minimumSamples.appointmentRate
        ? stats.appointmentRate
        : baseline.appointmentRate,
    appointmentRateSource:
      stats.contacts >= minimumSamples.appointmentRate ? "calculated" : "starting",
    closeRate:
      stats.contacts >= minimumSamples.closeRate ? stats.closeRate : baseline.closeRate,
    closeRateSource: stats.contacts >= minimumSamples.closeRate ? "calculated" : "starting",
  };
}

function scopedActivities() {
  if (canViewTeam() && viewedUserId === "all") return activities;
  return activities.filter((activity) => activity.ownerId === viewedUserId);
}

function canViewTeam() {
  return ["admin", "manager"].includes(currentUser?.role);
}

function canManageUsers() {
  return ["admin", "manager"].includes(currentUser?.role);
}

function canDeleteActivity(activity) {
  return canViewTeam() || activity.ownerId === currentUser.id;
}

function getSettingsUser() {
  if (viewedUserId !== "all") {
    return users.find((user) => user.id === viewedUserId) || currentUser;
  }
  return currentUser;
}

function syncGoalInputs() {
  const targetGoals = combinedGoals();
  els.goalDoors.value = targetGoals.doors;
  els.goalContacts.value = targetGoals.contacts;
  els.goalAppointments.value = targetGoals.appointments;
  els.goalSales.value = targetGoals.sales;

  const editingTeam = viewedUserId === "all";
  [els.goalDoors, els.goalContacts, els.goalAppointments, els.goalSales].forEach((input) => {
    input.disabled = editingTeam;
  });
}

function syncSettingsInputs() {
  const targetUser = getSettingsUser();
  els.settingsOwnerLabel.textContent = `Editing ${targetUser.name}`;
  els.settingsGoalDoors.value = targetUser.goals.doors;
  els.settingsGoalContacts.value = targetUser.goals.contacts;
  els.settingsGoalAppointments.value = targetUser.goals.appointments;
  els.settingsGoalSales.value = targetUser.goals.sales;
  els.baselineContactRate.value = targetUser.baselines.contactRate;
  els.baselineAppointmentRate.value = targetUser.baselines.appointmentRate;
  els.baselineCloseRate.value = targetUser.baselines.closeRate;
}

function combinedGoals() {
  const visibleUsers = visibleUserList();
  return visibleUsers.reduce(
    (total, user) => ({
      doors: total.doors + user.goals.doors,
      contacts: total.contacts + user.goals.contacts,
      appointments: total.appointments + user.goals.appointments,
      sales: total.sales + user.goals.sales,
    }),
    { doors: 0, contacts: 0, appointments: 0, sales: 0 },
  );
}

function combinedBaselines() {
  const visibleUsers = visibleUserList();
  const count = visibleUsers.length || 1;
  return visibleUsers.reduce(
    (total, user) => ({
      contactRate: Math.round(total.contactRate + user.baselines.contactRate / count),
      appointmentRate: Math.round(total.appointmentRate + user.baselines.appointmentRate / count),
      closeRate: Math.round(total.closeRate + user.baselines.closeRate / count),
    }),
    { contactRate: 0, appointmentRate: 0, closeRate: 0 },
  );
}

function visibleUserList() {
  if (canViewTeam() && viewedUserId === "all") return users;
  return [users.find((user) => user.id === viewedUserId) || currentUser];
}

function rangeGoal(key) {
  const multiplier = activeRange === "week" ? 7 : activeRange === "month" ? 30 : 1;
  return combinedGoals()[key] * multiplier;
}

function revenueForRange(list, range) {
  return list
    .filter((activity) => inRange(activity.createdAt, range))
    .reduce((total, activity) => total + (Number(activity.revenue) || 0), 0);
}

function doorsNeededForSales(salesGoal, rates = combinedModeledRates()) {
  const answerRate = Number(rates.contactRate) || 0;
  const closeRate = Number(rates.closeRate) || 0;
  const conversion = (answerRate / 100) * (closeRate / 100);
  if (!salesGoal || !conversion) return 0;
  return Math.ceil(salesGoal / conversion);
}

function combinedModeledRates() {
  return getModeledRates(getStats(scopedActivities({ includeRange: false })));
}

function quickLogTitle(outcome) {
  const label = outcomeMeta[outcome]?.label || "Quick log";
  return `${label} quick log`;
}

function inRange(isoDate, range) {
  const date = startOfDay(new Date(isoDate));
  const now = startOfDay(new Date());

  if (range === "today") return date.getTime() === now.getTime();

  const start = new Date(now);
  if (range === "week") start.setDate(now.getDate() - 6);
  if (range === "month") start.setDate(now.getDate() - 29);
  if (range === "year") start.setDate(now.getDate() - 364);

  return date >= start && date <= now;
}

function rateSource(source) {
  return source === "calculated" ? "(calculated)" : "(starting)";
}

function labelForRange(range) {
  return { today: "Today", week: "Last 7 days", month: "Last 30 days" }[range];
}

function userName(id) {
  return users.find((user) => user.id === id)?.name || "Unknown user";
}

function percent(value, total) {
  if (!total) return 0;
  return Math.round((value / total) * 100);
}

function clampPercent(value) {
  return Math.min(Math.max(Number(value) || 0, 0), 100);
}

function formatMoney(value) {
  return Number(value).toLocaleString(undefined, { maximumFractionDigits: 0 });
}

function formatDate(value) {
  return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(
    new Date(`${value}T00:00:00`),
  );
}

function formatDateTime(value) {
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(value));
}

function formatTime(value, options = {}) {
  return new Intl.DateTimeFormat(undefined, {
    hour: "numeric",
    minute: "2-digit",
    second: options.includeSeconds ? "2-digit" : undefined,
    timeZone: selectedTimeZone,
    timeZoneName: "short",
  }).format(new Date(value));
}

function timeUntil(value) {
  const remaining = Math.max(0, value - Date.now());
  const totalMinutes = Math.ceil(remaining / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours && minutes) return `${hours}h ${minutes}m`;
  if (hours) return `${hours}h`;
  return `${minutes}m`;
}

function getGoBackDelayMs() {
  const hours = clampNumber(els.goBackHours.value, 0, 12);
  const minutes = clampNumber(els.goBackMinutes.value, 0, 59);
  const seconds = clampNumber(els.goBackSeconds.value, 0, 59);
  const totalSeconds = Math.min(hours * 3600 + minutes * 60 + seconds, 12 * 3600);
  els.goBackHours.value = Math.floor(totalSeconds / 3600);
  els.goBackMinutes.value = Math.floor((totalSeconds % 3600) / 60);
  els.goBackSeconds.value = totalSeconds % 60;
  return totalSeconds * 1000;
}

function clampNumber(value, min, max) {
  return Math.min(Math.max(Number(value) || 0, min), max);
}

function startOfDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function valueOf(selector) {
  return document.querySelector(selector).value.trim();
}

function ensureDefaultUsers() {
  if (users.length) return;

  users = [
    {
      id: "owner",
      name: "Michael S",
      email: "michael@nextdoorkpi.app",
      role: "admin",
      password: "password123",
      goals: { ...defaultGoals },
      baselines: { ...defaultBaselines },
      customKpis: [
        { id: createId(), name: "Answer to go-back", current: 20, target: 30 },
      ],
    },
    {
      id: "rep-demo",
      name: "Demo Rep",
      email: "rep@nextdoorkpi.app",
      role: "rep",
      password: "password123",
      goals: { doors: 60, contacts: 24, appointments: 4, sales: 1 },
      baselines: { contactRate: 40, appointmentRate: 18, closeRate: 7 },
      customKpis: [],
    },
  ];
  saveUsers();
}

function normalizeUsers() {
  let changed = false;
  users = users.map((user) => {
    const isDemoUser = ["owner", "rep-demo"].includes(user.id);
    const nextUser = {
      ...user,
      name: user.id === "owner" ? "Michael S" : user.name,
      email: user.id === "owner" ? "michael@nextdoorkpi.app" : user.email,
      password:
        isDemoUser && (!user.password || user.password === "1234")
          ? "password123"
          : user.password || user.pin || "password123",
      goals: { ...defaultGoals, ...(user.goals || {}) },
      baselines: { ...defaultBaselines, ...(user.baselines || {}) },
      customKpis: user.customKpis || [],
    };
    delete nextUser.pin;
    changed = changed || JSON.stringify(nextUser) !== JSON.stringify(user);
    return nextUser;
  });
  if (changed) saveUsers();
}

function migrateOldActivities() {
  const oldActivities = readJson("nextdoorkpi.activities.v1", []);
  if (!oldActivities.length || activities.length) return;

  activities = oldActivities.map((activity) => ({ ...activity, ownerId: "owner" }));
  saveActivities();
}

function saveActivities() {
  localStorage.setItem(ACTIVITY_KEY, JSON.stringify(activities));
}

function saveGoBackAlarms() {
  localStorage.setItem(GO_BACK_KEY, JSON.stringify(goBackAlarms));
}

function saveUsers() {
  localStorage.setItem(USER_KEY, JSON.stringify(users));
  currentUser = users.find((user) => user.id === currentUser?.id) || currentUser;
}

function readJson(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) || fallback;
  } catch {
    return fallback;
  }
}

function createId() {
  if (crypto.randomUUID) return crypto.randomUUID();
  return `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function emptyState(title, message) {
  return `
    <div class="empty-state">
      <strong>${title}</strong>
      <span>${message}</span>
    </div>
  `;
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function buildDemoData() {
  const now = new Date();
  const visibleUsers = canViewTeam() ? users : [currentUser];
  const sample = [
    ["sale", 1200, "", "Closed a premium package."],
    ["go-back", 0, 1, "Decision maker wants evening call."],
    ["no-answer", 0, 2, "Try again after 6 PM."],
    ["contacted", 0, 3, "Answered and asked about financing."],
    ["not-interested", 0, "", "Currently under contract."],
    ["yelled", 0, "", "Do not revisit this one."],
  ];

  return sample.map(([outcome, revenue, followUpOffset, notes], index) => {
    const createdAt = new Date(now);
    createdAt.setDate(now.getDate() - Math.min(index, 4));
    const followUpDate =
      followUpOffset === ""
        ? ""
        : new Date(now.getFullYear(), now.getMonth(), now.getDate() + followUpOffset)
            .toISOString()
            .slice(0, 10);

    return {
      id: createId(),
      ownerId: visibleUsers[index % visibleUsers.length].id,
      createdAt: createdAt.toISOString(),
      address: quickLogTitle(outcome),
      contactName: "",
      outcome,
      revenue,
      followUpDate,
      notes,
    };
  });
}

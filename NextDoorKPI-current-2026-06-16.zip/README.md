# NextDoorKPI

A simple door-to-door sales tracker for logging knocks, outcomes, follow-ups, sales, revenue, and daily KPI progress.

## What it does

- Supports local demo users with email/password sign-in and roles: admin, manager, and rep.
- Lets admins/managers view team data while reps only see their own data.
- Tracks doors knocked, doors answered, go backs, sales, contract value, answer rate, go-back rate, and close rate.
- Lets reps use Quick Log buttons for no answer, not interested, sale, go back, grumpy grandpa, and answered.
- Shows daily Quick Log counts on each button and lets reps subtract one accidental tap.
- Uses separate tabs for Dashboard, Quick Log, Go Backs, History, Users, and Goals.
- Shows contract value only when logging or editing a sale.
- Lets reps edit quick knocks if they tap the wrong outcome.
- Shows revenue graphs for day, week, month, and year plus outcome mix, sales pace, and field insights.
- Includes Go Back alarms with name, address, notes, hours/minutes/seconds wait time up to 12 hours, projected alarm time, and due alerts.
- Includes an always-visible clock with selectable US time zones.
- Lets each user customize goals, starting percentages, custom percentage trackers, and sales-goal door requirements for day, week, month, and summer.
- Uses starting percentages until there is enough activity to calculate real rates.
- Saves data in the browser using local storage.

## How to open it

Open `index.html` in any modern browser.

Default users:

- Michael S: `michael@nextdoorkpi.app` / `password123`
- Demo Rep: `rep@nextdoorkpi.app` / `password123`

## Current limitations

- Users, roles, and passwords are only a local prototype.
- Google sign-in needs a hosted auth service like Supabase or Firebase.
- Data is saved only in the browser where the app is used.
- Data does not sync across phones, laptops, or browsers yet.
- Real multi-person access needs a hosted backend, database, and secure authentication.

## Possible next features

- GitHub Pages hosting
- Cloud database sync
- Secure login/accounts
- Mobile-first field mode
- Territory/map tracking
- Team manager dashboard
